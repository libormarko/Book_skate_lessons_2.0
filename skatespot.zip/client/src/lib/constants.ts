export const CITIES = [
  "Berlin",
  "Hamburg",
  "Munich",
  "Cologne",
  "Frankfurt",
  "Stuttgart",
  "Düsseldorf",
  "Leipzig",
  "Dortmund",
  "Essen"
];

export const FEATURES = [
  "Half-pipe",
  "Bowl",
  "Street section",
  "Mini ramp",
  "Vert ramp",
  "Rails",
  "Stairs",
  "Ledges"
];

export const FACILITIES = [
  "Parking",
  "Shop",
  "Restrooms",
  "Lockers",
  "Rentals",
  "Cafe",
  "First aid"
];

export const BOARD_LEVELS = [
  "Beginner",
  "Intermediate",
  "Advanced",
  "Expert"
];
